package com.example.demo

object A {

    fun getData(){

    }

}